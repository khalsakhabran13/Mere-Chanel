# Mere Chanel Android TV - FIXED
This version opens standard YouTube URLs with ACTION_VIEW and does not force a package name.
It uses the requested four categories and the supplied YouTube channel/live URLs.
