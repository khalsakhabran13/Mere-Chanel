package com.khalsa.merechanel

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

data class Channel(val name: String, val url: String)

class MainActivity : AppCompatActivity() {
    private val sections = listOf(
        "🙏 ਗੁਰਬਾਣੀ ਕੀਰਤਨ" to listOf(
            Channel("SGPC Sri Amritsar", "https://www.youtube.com/@sgpcsriamritsar"),
            Channel("Live Sri Fatehgarh Sahib", "https://www.youtube.com/@livesrifatehgarhsahib"),
            Channel("Gurdwara Sis Ganj Sahib", "https://www.youtube.com/@gurdwarasisganjsahib8055"),
            Channel("Hazur Sahib Live Channel", "https://www.youtube.com/@hazursahiblivechannel1059"),
            Channel("Live EPBSpbyWHR4", "https://www.youtube.com/watch?v=EPBSpbyWHR4"),
            Channel("Live dkEIFbFlgmU", "https://www.youtube.com/watch?v=dkEIFbFlgmU"),
            Channel("Live tyFWEleYQOA", "https://www.youtube.com/watch?v=tyFWEleYQOA"),
            Channel("Live IBAEUwViQ-w", "https://www.youtube.com/watch?v=IBAEUwViQ-w")
        ),
        "📰 ਖ਼ਬਰਾਂ" to listOf(
            Channel("Janhit TV Patna", "https://www.youtube.com/@janhittvpatna"),
            Channel("PTC News", "https://www.youtube.com/@ptcnews"),
            Channel("News18 Punjab", "https://www.youtube.com/@news18_punjab"),
            Channel("Rozana Spokesman", "https://www.youtube.com/@rozanaspokesmanofficial"),
            Channel("Dhunda TV", "https://www.youtube.com/@dhundatv"),
            Channel("Bhullar TV News", "https://www.youtube.com/@bhullartvnews")
        ),
        "📺 ਪੰਜਾਬੀ ਚੈਨਲ" to listOf(
            Channel("Emmpee", "https://www.youtube.com/@emmpee"),
            Channel("Gursagar Channel", "https://www.youtube.com/@gursagarchannel")
        ),
        "🔴 ਲਾਈਵ ਚੈਨਲ" to listOf(
            Channel("Live EPBSpbyWHR4", "https://www.youtube.com/watch?v=EPBSpbyWHR4"),
            Channel("Live dkEIFbFlgmU", "https://www.youtube.com/watch?v=dkEIFbFlgmU"),
            Channel("Live tyFWEleYQOA", "https://www.youtube.com/watch?v=tyFWEleYQOA"),
            Channel("Live IBAEUwViQ-w", "https://www.youtube.com/watch?v=IBAEUwViQ-w")
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 35, 50, 50)
            setBackgroundColor(Color.rgb(10,10,10))
        }
        main.addView(TextView(this).apply {
            text = "ਮੇਰੇ ਚੈਨਲ"
            textSize = 34f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0,0,0,28)
        })
        sections.forEach { (section, channels) ->
            main.addView(TextView(this).apply {
                text = section
                textSize = 27f
                setTextColor(Color.rgb(255,193,7))
                setPadding(0,18,0,12)
            })
            channels.forEach { ch ->
                main.addView(Button(this).apply {
                    text = ch.name
                    textSize = 22f
                    isAllCaps = false
                    setTextColor(Color.WHITE)
                    setBackgroundColor(Color.rgb(35,35,35))
                    isFocusable = true
                    setOnClickListener { openYouTube(ch.url) }
                }, LinearLayout.LayoutParams(-1,82).apply { setMargins(0,0,0,10) })
            }
        }
        scroll.addView(main)
        setContentView(scroll)
    }

    private fun openYouTube(url: String) {
        // Do NOT force a YouTube package. Let Android open the installed
        // YouTube app; if unavailable, use the browser.
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        try {
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "YouTube ਨਹੀਂ ਖੁੱਲ੍ਹ ਸਕਿਆ", Toast.LENGTH_LONG).show()
        }
    }
}
